
def model () :
    data = pd.read_csv("C:\Users\Noell\Documents\DATA_CHALLENGE\train.csv")
    stop_words = set(stopwords.words('english'))
    # Lemmatisation
    lemmatizer = WordNetLemmatizer()
    # Adjectifs
    data['text_lem'] = data['text'].apply(
        lambda x: ' '.join([lemmatizer.lemmatize(word, pos="v") for word in x.split()]))
    # Adverbes
    data['text_lem'] = data['text_lem'].apply(
        lambda x: ' '.join([lemmatizer.lemmatize(word, pos="a") for word in x.split()]))

    # Importance mots dans document
    # Enleve les accents, mets tout en minuscule et tokenisation : separation du texte en mots
    Tfidf_vect = TfidfVectorizer(use_idf=True, stop_words=stop_words, max_df=0.3, min_df=0.008, strip_accents="ascii")
    Tfidf_vect.fit(data['text_lem'])
    # Enlever variable temporaire 'text'?
    Train_X_Tfidf = Tfidf_vect.transform(data['text_lem'])
    model_result = LogisticRegression(random_state=40).fit(Train_X_Tfidf, data['label'])

    return Tfidf_vect.vocabulary_,model_result